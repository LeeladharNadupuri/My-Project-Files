import React from 'react';
import { Github, Linkedin, Mail, Phone, Sparkles } from 'lucide-react';

const Hero = () => {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg width=%2260%22 height=%2260%22 viewBox=%220 0 60 60%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cg fill=%22none%22 fill-rule=%22evenodd%22%3E%3Cg fill=%22%239C92AC%22 fill-opacity=%220.1%22%3E%3Ccircle cx=%2230%22 cy=%2230%22 r=%224%22/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')] opacity-20"></div>
        
        {/* Floating Elements */}
        <div className="absolute top-20 left-10 w-20 h-20 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full opacity-20 animate-bounce"></div>
        <div className="absolute top-40 right-20 w-16 h-16 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full opacity-20 animate-pulse"></div>
        <div className="absolute bottom-20 left-20 w-12 h-12 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full opacity-20 animate-bounce delay-1000"></div>
        <div className="absolute bottom-40 right-10 w-24 h-24 bg-gradient-to-r from-green-500 to-teal-500 rounded-full opacity-20 animate-pulse delay-500"></div>
      </div>

      <div className="container mx-auto px-4 py-20 relative z-10">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-12">
          <div className="flex-1 text-center lg:text-left">
            <div className="flex items-center gap-2 mb-4 justify-center lg:justify-start">
              <Sparkles className="w-6 h-6 text-yellow-400 animate-pulse" />
              <span className="text-purple-300 font-medium">Welcome to my portfolio</span>
            </div>
            
            <h1 className="text-4xl lg:text-7xl font-bold text-transparent bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text mb-6 leading-tight">
              Hi, I'm{' '}
              <span className="bg-gradient-to-r from-pink-400 via-purple-400 to-blue-400 bg-clip-text text-transparent animate-pulse">
                Leeladhar
              </span>
              <br />
              <span className="bg-gradient-to-r from-cyan-400 via-blue-400 to-purple-400 bg-clip-text text-transparent">
                Nadupuri
              </span>
            </h1>
            
            <div className="text-xl lg:text-3xl text-purple-200 mb-8 font-light">
              <span className="inline-block animate-bounce">🎓</span> BCA Student & 
              <span className="bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent font-semibold"> Aspiring Developer</span>
            </div>
            
            <p className="text-lg text-purple-100 mb-8 max-w-2xl leading-relaxed">
              Currently pursuing my final year of BCA at Aditya Degree College. 
              Passionate about creating innovative solutions with{' '}
              <span className="text-yellow-400 font-semibold">Python</span>, 
              <span className="text-blue-400 font-semibold"> web development</span>, 
              and <span className="text-green-400 font-semibold">database management</span>.
            </p>
            
            <div className="flex flex-wrap justify-center lg:justify-start gap-4 mb-8">
              <a 
                href="https://github.com/LeeladharNadupuri" 
                target="_blank" 
                rel="noopener noreferrer"
                className="group flex items-center gap-2 bg-gradient-to-r from-gray-800 to-gray-900 text-cyan-300 px-6 py-3 rounded-full hover:from-gray-700 hover:to-gray-800 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl border border-cyan-500/30"
              >
                <Github size={20} className="group-hover:rotate-12 transition-transform" />
                GitHub
              </a>
              <a 
                href="https://www.linkedin.com/in/leeladhar-nadupuri-233b1b331?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app" 
                target="_blank" 
                rel="noopener noreferrer"
                className="group flex items-center gap-2 bg-gradient-to-r from-blue-600 to-blue-700 text-cyan-100 px-6 py-3 rounded-full hover:from-blue-500 hover:to-blue-600 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl border border-blue-400/30"
              >
                <Linkedin size={20} className="group-hover:rotate-12 transition-transform" />
                LinkedIn
              </a>
            </div>

            <div className="flex flex-col sm:flex-row gap-6 text-purple-200">
              <div className="flex items-center gap-3 group">
                <div className="w-10 h-10 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Mail size={18} className="text-cyan-100" />
                </div>
                <span className="group-hover:text-cyan-300 transition-colors">nleela006@gmail.com</span>
              </div>
              <div className="flex items-center gap-3 group">
                <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Phone size={18} className="text-cyan-100" />
                </div>
                <span className="group-hover:text-cyan-300 transition-colors">8179885181</span>
              </div>
            </div>
          </div>
          
          <div className="flex-shrink-0 relative">
            <div className="relative">
              {/* Glowing ring */}
              <div className="absolute -inset-4 bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 rounded-full opacity-75 blur-lg animate-pulse"></div>
              
              {/* Profile image */}
              <div className="relative w-80 h-80 rounded-full overflow-hidden shadow-2xl border-4 border-cyan-400/30 backdrop-blur-sm">
                <img 
                  src="https://i.imgur.com/CRmMKL5.jpeg" 
                  alt="Leeladhar Nadupuri"
                  className="w-full h-full object-cover hover:scale-110 transition-transform duration-500"
                />
              </div>
              
              {/* Floating badges */}
              <div className="absolute -top-4 -right-4 bg-gradient-to-r from-yellow-400 to-orange-500 text-gray-900 px-3 py-1 rounded-full text-sm font-semibold animate-bounce">
                Python 🐍
              </div>
              <div className="absolute -bottom-4 -left-4 bg-gradient-to-r from-green-400 to-blue-500 text-gray-900 px-3 py-1 rounded-full text-sm font-semibold animate-bounce delay-500">
                BCA Student 🎓
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;