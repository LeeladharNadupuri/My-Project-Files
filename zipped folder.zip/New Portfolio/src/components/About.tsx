import React from 'react';
import { User, Target, Heart, Code, Lightbulb, Rocket } from 'lucide-react';

const About = () => {
  return (
    <section id="about" className="py-20 bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute top-0 left-0 w-full h-full">
        <div className="absolute top-20 left-10 w-32 h-32 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full opacity-10 animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-40 h-40 bg-gradient-to-r from-blue-400 to-cyan-400 rounded-full opacity-10 animate-pulse delay-1000"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-purple-600 to-pink-600 text-cyan-100 px-4 py-2 rounded-full text-sm font-semibold mb-4">
            <Lightbulb size={16} className="animate-pulse" />
            Get to know me
          </div>
          <h2 className="text-5xl font-bold bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 bg-clip-text text-transparent mb-6">
            About Me
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            A passionate and dedicated BCA student with a strong foundation in programming 
            and a keen interest in creating innovative software solutions.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="group bg-gradient-to-br from-cyan-50 to-blue-100 backdrop-blur-sm rounded-2xl p-8 text-center shadow-xl hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 border border-purple-200">
            <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 group-hover:rotate-6 transition-all duration-300">
              <User className="w-10 h-10 text-cyan-100" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-4 group-hover:text-purple-600 transition-colors">Who I Am</h3>
            <p className="text-gray-700 leading-relaxed">
              I'm Leeladhar Nadupuri, a final-year BCA student at Aditya Degree College, 
              Gopalapatnam. I have a strong academic background with consistent performance 
              throughout my educational journey.
            </p>
            <div className="mt-4 flex justify-center">
              <div className="w-12 h-1 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full"></div>
            </div>
          </div>

          <div className="group bg-gradient-to-br from-green-50 to-teal-100 backdrop-blur-sm rounded-2xl p-8 text-center shadow-xl hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 border border-green-200">
            <div className="w-20 h-20 bg-gradient-to-r from-green-500 to-teal-600 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 group-hover:rotate-6 transition-all duration-300">
              <Code className="w-10 h-10 text-cyan-100" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-4 group-hover:text-green-600 transition-colors">What I Do</h3>
            <p className="text-gray-700 leading-relaxed">
              I specialize in Python programming and web development. I've worked on various 
              projects including community service applications, games, and utility tools 
              that solve real-world problems.
            </p>
            <div className="mt-4 flex justify-center">
              <div className="w-12 h-1 bg-gradient-to-r from-green-500 to-teal-600 rounded-full"></div>
            </div>
          </div>

          <div className="group bg-gradient-to-br from-pink-50 to-rose-100 backdrop-blur-sm rounded-2xl p-8 text-center shadow-xl hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 border border-pink-200">
            <div className="w-20 h-20 bg-gradient-to-r from-pink-500 to-red-500 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 group-hover:rotate-6 transition-all duration-300">
              <Heart className="w-10 h-10 text-cyan-100" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-4 group-hover:text-pink-600 transition-colors">What I Love</h3>
            <p className="text-gray-700 leading-relaxed">
              I'm passionate about creating solutions that make a difference. Whether it's 
              developing applications for community service or building fun interactive games, 
              I love bringing ideas to life through code.
            </p>
            <div className="mt-4 flex justify-center">
              <div className="w-12 h-1 bg-gradient-to-r from-pink-500 to-red-500 rounded-full"></div>
            </div>
          </div>
        </div>

        {/* Stats Section */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8">
          {[
            { number: '7+', label: 'Projects', icon: <Rocket className="w-6 h-6" />, color: 'from-purple-500 to-pink-500' },
            { number: '3+', label: 'Years Learning', icon: <Code className="w-6 h-6" />, color: 'from-blue-500 to-cyan-500' },
            { number: '5+', label: 'Technologies', icon: <Target className="w-6 h-6" />, color: 'from-green-500 to-teal-500' },
            { number: '1', label: 'Community Project', icon: <Heart className="w-6 h-6" />, color: 'from-orange-500 to-red-500' }
          ].map((stat, index) => (
            <div key={index} className="text-center group">
              <div className={`w-16 h-16 bg-gradient-to-r ${stat.color} rounded-2xl flex items-center justify-center mx-auto mb-3 text-cyan-100 group-hover:scale-110 transition-transform`}>
                {stat.icon}
              </div>
              <div className="text-3xl font-bold text-gray-900 mb-1">{stat.number}</div>
              <div className="text-gray-600 font-medium">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;