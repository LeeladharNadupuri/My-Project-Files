import React from 'react';
import { Heart, Github, Linkedin, Mail, ArrowUp } from 'lucide-react';

const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-gradient-to-br from-gray-900 via-purple-900 to-indigo-900 text-cyan-100 py-12 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0">
        <div className="absolute top-10 left-10 w-20 h-20 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full opacity-10 animate-pulse"></div>
        <div className="absolute bottom-10 right-10 w-16 h-16 bg-gradient-to-r from-blue-400 to-cyan-400 rounded-full opacity-10 animate-bounce"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          {/* Brand Section */}
          <div className="text-center md:text-left">
            <h3 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent mb-4">
              Leeladhar Nadupuri
            </h3>
            <p className="text-purple-200 leading-relaxed">
              BCA Student & Aspiring Developer passionate about creating innovative solutions 
              and making a positive impact through technology.
            </p>
          </div>

          {/* Quick Links */}
          <div className="text-center">
            <h4 className="text-lg font-semibold text-cyan-100 mb-4">Quick Links</h4>
            <div className="space-y-2">
              {['About', 'Education', 'Skills', 'Projects', 'Contact'].map((link) => (
                <button
                  key={link}
                  onClick={() => {
                    const element = document.getElementById(link.toLowerCase());
                    if (element) element.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="block text-purple-200 hover:text-cyan-300 transition-colors duration-300 mx-auto"
                >
                  {link}
                </button>
              ))}
            </div>
          </div>

          {/* Contact Info */}
          <div className="text-center md:text-right">
            <h4 className="text-lg font-semibold text-cyan-100 mb-4">Get In Touch</h4>
            <div className="space-y-2 text-purple-200">
              <p>📧 nleela006@gmail.com</p>
              <p>📱 8179885181</p>
              <p>📍 Gopalapatnam, India</p>
            </div>
            
            <div className="flex justify-center md:justify-end gap-4 mt-4">
              <a 
                href="https://github.com/LeeladharNadupuri" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-10 h-10 bg-gradient-to-r from-gray-700 to-gray-800 rounded-lg flex items-center justify-center hover:from-gray-600 hover:to-gray-700 transition-all duration-300 transform hover:scale-110 border border-cyan-500/30"
              >
                <Github size={18} />
              </a>
              <a 
                href="https://www.linkedin.com/in/leeladhar-nadupuri-233b1b331?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-10 h-10 bg-gradient-to-r from-blue-600 to-blue-700 rounded-lg flex items-center justify-center hover:from-blue-500 hover:to-blue-600 transition-all duration-300 transform hover:scale-110 border border-blue-400/30"
              >
                <Linkedin size={18} />
              </a>
              <a 
                href="mailto:nleela006@gmail.com"
                className="w-10 h-10 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg flex items-center justify-center hover:from-purple-500 hover:to-pink-500 transition-all duration-300 transform hover:scale-110"
              >
                <Mail size={18} />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-purple-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="flex items-center justify-center gap-2 text-purple-200 mb-4 md:mb-0">
              Made with <Heart size={16} className="text-red-400 animate-pulse" /> by Leeladhar Nadupuri
            </p>
            <div className="flex items-center gap-4">
              <p className="text-purple-300">
                © 2024 Leeladhar Nadupuri. All rights reserved.
              </p>
              <button
                onClick={scrollToTop}
                className="w-10 h-10 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full flex items-center justify-center hover:from-purple-500 hover:to-pink-500 transition-all duration-300 transform hover:scale-110 group"
              >
                <ArrowUp size={18} className="group-hover:-translate-y-1 transition-transform" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;