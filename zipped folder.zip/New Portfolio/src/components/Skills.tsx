import React from 'react';
import { Code, Database, Globe, Terminal, Zap, Cpu, Palette, Rocket } from 'lucide-react';

const Skills = () => {
  const skillCategories = [
    {
      title: "Programming Languages",
      icon: <Code className="w-8 h-8" />,
      skills: [
        { name: "Python", level: 90, color: "from-yellow-400 to-yellow-600" },
        { name: "C", level: 75, color: "from-blue-400 to-blue-600" },
        { name: "C++", level: 80, color: "from-purple-400 to-purple-600" }
      ],
      bgColor: "from-blue-500 to-purple-600",
      cardBg: "from-blue-50 to-purple-50"
    },
    {
      title: "Web Development",
      icon: <Globe className="w-8 h-8" />,
      skills: [
        { name: "HTML", level: 85, color: "from-orange-400 to-red-500" },
        { name: "CSS", level: 80, color: "from-blue-400 to-cyan-500" },
        { name: "JavaScript", level: 75, color: "from-yellow-400 to-orange-500" }
      ],
      bgColor: "from-green-500 to-teal-600",
      cardBg: "from-green-50 to-teal-50"
    },
    {
      title: "Database",
      icon: <Database className="w-8 h-8" />,
      skills: [
        { name: "SQL", level: 85, color: "from-indigo-400 to-purple-500" },
        { name: "Database Design", level: 80, color: "from-pink-400 to-rose-500" }
      ],
      bgColor: "from-purple-500 to-pink-600",
      cardBg: "from-purple-50 to-pink-50"
    },
    {
      title: "Tools & Technologies",
      icon: <Terminal className="w-8 h-8" />,
      skills: [
        { name: "Git", level: 75, color: "from-gray-400 to-gray-600" },
        { name: "Version Control", level: 80, color: "from-green-400 to-emerald-500" },
        { name: "Problem Solving", level: 90, color: "from-orange-400 to-red-500" }
      ],
      bgColor: "from-orange-500 to-red-600",
      cardBg: "from-orange-50 to-red-50"
    }
  ];

  return (
    <section id="skills" className="py-20 bg-gradient-to-br from-gray-50 via-blue-50 to-purple-50 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-10 w-32 h-32 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full opacity-10 animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-40 h-40 bg-gradient-to-r from-blue-400 to-cyan-400 rounded-full opacity-10 animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-60 h-60 bg-gradient-to-r from-green-400 to-teal-400 rounded-full opacity-5 animate-spin" style={{ animationDuration: '20s' }}></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-2 rounded-full text-sm font-semibold mb-4">
            <Zap size={16} className="animate-pulse" />
            My Expertise
          </div>
          <h2 className="text-5xl font-bold bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 bg-clip-text text-transparent mb-6">
            Skills & Technologies
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            A comprehensive overview of my technical skills and areas of expertise, 
            constantly evolving and growing.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {skillCategories.map((category, index) => (
            <div key={index} className={`group bg-gradient-to-r ${category.cardBg} backdrop-blur-sm rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 border border-white/50`}>
              <div className="flex items-center gap-4 mb-6">
                <div className={`w-16 h-16 bg-gradient-to-r ${category.bgColor} rounded-2xl flex items-center justify-center text-white group-hover:scale-110 group-hover:rotate-6 transition-all duration-300`}>
                  {category.icon}
                </div>
                <h3 className="text-2xl font-bold text-gray-900">{category.title}</h3>
              </div>
              
              <div className="space-y-4">
                {category.skills.map((skill, skillIndex) => (
                  <div key={skillIndex} className="group/skill">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-gray-700 font-medium">{skill.name}</span>
                      <span className="text-gray-500 text-sm font-semibold">{skill.level}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
                      <div 
                        className={`h-full bg-gradient-to-r ${skill.color} rounded-full transition-all duration-1000 ease-out group-hover/skill:animate-pulse`}
                        style={{ width: `${skill.level}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Additional Skills Highlights */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { icon: <Cpu className="w-6 h-6" />, title: "Problem Solving", color: "from-red-500 to-pink-500" },
            { icon: <Palette className="w-6 h-6" />, title: "Creative Thinking", color: "from-purple-500 to-indigo-500" },
            { icon: <Rocket className="w-6 h-6" />, title: "Quick Learning", color: "from-green-500 to-teal-500" },
            { icon: <Zap className="w-6 h-6" />, title: "Innovation", color: "from-yellow-500 to-orange-500" }
          ].map((item, index) => (
            <div key={index} className="group text-center">
              <div className={`w-16 h-16 bg-gradient-to-r ${item.color} rounded-2xl flex items-center justify-center mx-auto mb-3 text-white group-hover:scale-110 group-hover:rotate-12 transition-all duration-300 shadow-lg`}>
                {item.icon}
              </div>
              <h4 className="font-semibold text-gray-900 group-hover:text-purple-600 transition-colors">{item.title}</h4>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;