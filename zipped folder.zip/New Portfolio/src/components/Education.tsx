import React from 'react';
import { GraduationCap, Calendar, Award, Star, BookOpen } from 'lucide-react';

const Education = () => {
  const educationData = [
    {
      degree: "Bachelor of Computer Applications (BCA)",
      institution: "Aditya Degree College, Gopalapatnam",
      period: "2023 - 2026",
      status: "Final Year (Currently Pursuing)",
      icon: <GraduationCap className="w-8 h-8" />,
      color: "from-purple-500 to-pink-500",
      bgColor: "from-purple-50 to-pink-50"
    },
    {
      degree: "Intermediate Education",
      institution: "NRI Junior College",
      period: "2021 - 2023",
      status: "Completed with 79.1%",
      icon: <Award className="w-8 h-8" />,
      color: "from-blue-500 to-cyan-500",
      bgColor: "from-blue-50 to-cyan-50"
    },
    {
      degree: "Secondary School Education",
      institution: "Govt High School, Sabbavaram",
      period: "Completed",
      status: "CGPA: 8.8",
      icon: <Star className="w-8 h-8" />,
      color: "from-green-500 to-teal-500",
      bgColor: "from-green-50 to-teal-50"
    }
  ];

  return (
    <section id="education" className="py-20 bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0">
        <div className="absolute top-10 left-10 w-20 h-20 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full opacity-20 animate-bounce"></div>
        <div className="absolute top-40 right-20 w-16 h-16 bg-gradient-to-r from-green-400 to-blue-500 rounded-full opacity-20 animate-pulse"></div>
        <div className="absolute bottom-20 left-20 w-24 h-24 bg-gradient-to-r from-pink-400 to-purple-500 rounded-full opacity-20 animate-bounce delay-1000"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-yellow-400 to-orange-500 text-gray-900 px-4 py-2 rounded-full text-sm font-semibold mb-4">
            <BookOpen size={16} className="animate-pulse" />
            My Academic Journey
          </div>
          <h2 className="text-5xl font-bold text-transparent bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text mb-6">
            Education
          </h2>
          <p className="text-xl text-purple-200 max-w-3xl mx-auto leading-relaxed">
            My academic journey showcasing consistent performance and dedication to learning 
            throughout my educational path.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          {educationData.map((edu, index) => (
            <div key={index} className="relative mb-12 last:mb-0">
              {/* Timeline line */}
              {index !== educationData.length - 1 && (
                <div className="absolute left-10 top-20 w-1 h-32 bg-gradient-to-b from-purple-400 to-pink-400 rounded-full opacity-50"></div>
              )}
              
              <div className="flex items-start gap-8 group">
                <div className={`flex-shrink-0 w-20 h-20 bg-gradient-to-r ${edu.color} rounded-2xl flex items-center justify-center text-cyan-100 shadow-lg group-hover:scale-110 group-hover:rotate-6 transition-all duration-300`}>
                  {edu.icon}
                </div>
                
                <div className={`flex-1 bg-gradient-to-r ${edu.bgColor} backdrop-blur-sm rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 border border-purple-200/30`}>
                  <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-4">
                    <h3 className="text-2xl font-bold text-gray-900 mb-2 lg:mb-0">{edu.degree}</h3>
                    <div className="flex items-center gap-2 text-gray-600">
                      <Calendar size={18} />
                      <span className="font-medium">{edu.period}</span>
                    </div>
                  </div>
                  
                  <p className="text-gray-700 mb-3 text-lg">{edu.institution}</p>
                  <div className={`inline-flex items-center gap-2 bg-gradient-to-r ${edu.color} text-cyan-100 px-4 py-2 rounded-full font-semibold`}>
                    <Award size={16} />
                    {edu.status}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Achievement highlights */}
        <div className="mt-16 text-center">
          <div className="inline-flex items-center gap-4 bg-gradient-to-r from-cyan-500/20 to-purple-500/20 backdrop-blur-sm rounded-2xl p-6 border border-cyan-400/30">
            <div className="text-3xl">🎯</div>
            <div className="text-cyan-100">
              <div className="text-lg font-semibold">Consistent Academic Excellence</div>
              <div className="text-purple-200">Maintaining strong performance throughout my educational journey</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Education;