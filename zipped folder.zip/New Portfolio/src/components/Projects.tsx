import React from 'react';
import { ExternalLink, Github, Smartphone, Calculator, Gamepad2, Heart, Receipt, Coins, Sparkles, Star } from 'lucide-react';

const Projects = () => {
  const projects = [
    {
      title: "Online UPI Transactions",
      description: "A community service project focused on digital payment solutions and UPI transaction management with secure processing.",
      category: "Community Service",
      icon: <Smartphone className="w-8 h-8" />,
      technologies: ["Python", "Database Management", "Security"],
      color: "from-blue-500 to-cyan-500",
      bgColor: "from-blue-50 to-cyan-50",
      featured: true
    },
    {
      title: "Student Results Management",
      description: "A comprehensive system for managing and displaying student academic results with advanced data analysis and reporting features.",
      category: "Educational Tool",
      icon: <Calculator className="w-8 h-8" />,
      technologies: ["Python", "Data Processing", "Analytics"],
      color: "from-green-500 to-emerald-500",
      bgColor: "from-green-50 to-emerald-50",
      featured: true
    },
    {
      title: "Password Generator",
      description: "A secure password generation tool with customizable parameters, encryption standards, and enhanced security features.",
      category: "Utility",
      icon: <ExternalLink className="w-8 h-8" />,
      technologies: ["Python", "Security", "Encryption"],
      color: "from-purple-500 to-violet-500",
      bgColor: "from-purple-50 to-violet-50"
    },
    {
      title: "Rock Paper Scissors Game",
      description: "An interactive game implementation with intelligent computer AI opponent, score tracking, and engaging user interface.",
      category: "Game",
      icon: <Gamepad2 className="w-8 h-8" />,
      technologies: ["Python", "Game Logic", "AI"],
      color: "from-orange-500 to-red-500",
      bgColor: "from-orange-50 to-red-50"
    },
    {
      title: "Love Calculator",
      description: "A fun application that calculates compatibility between two names using sophisticated algorithmic approach and statistics.",
      category: "Entertainment",
      icon: <Heart className="w-8 h-8" />,
      technologies: ["Python", "Algorithm", "Statistics"],
      color: "from-pink-500 to-rose-500",
      bgColor: "from-pink-50 to-rose-50"
    },
    {
      title: "Restaurant Bill Calculator",
      description: "A comprehensive billing system for restaurants with menu management, tax calculations, and automatic billing features.",
      category: "Business Tool",
      icon: <Receipt className="w-8 h-8" />,
      technologies: ["Python", "Business Logic", "Database"],
      color: "from-indigo-500 to-purple-500",
      bgColor: "from-indigo-50 to-purple-50"
    },
    {
      title: "Heads or Tails",
      description: "A simple yet engaging coin flip simulation game with probability tracking, statistics analysis, and visual feedback.",
      category: "Game",
      icon: <Coins className="w-8 h-8" />,
      technologies: ["Python", "Probability", "Statistics"],
      color: "from-yellow-500 to-amber-500",
      bgColor: "from-yellow-50 to-amber-50"
    }
  ];

  return (
    <section id="projects" className="py-20 bg-gradient-to-br from-gray-900 via-purple-900 to-indigo-900 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0">
        <div className="absolute top-10 left-10 w-20 h-20 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full opacity-20 animate-bounce"></div>
        <div className="absolute top-40 right-20 w-16 h-16 bg-gradient-to-r from-green-400 to-blue-500 rounded-full opacity-20 animate-pulse"></div>
        <div className="absolute bottom-20 left-20 w-24 h-24 bg-gradient-to-r from-pink-400 to-purple-500 rounded-full opacity-20 animate-bounce delay-1000"></div>
        <div className="absolute bottom-40 right-10 w-32 h-32 bg-gradient-to-r from-blue-400 to-cyan-500 rounded-full opacity-10 animate-pulse delay-500"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-4 py-2 rounded-full text-sm font-semibold mb-4">
            <Sparkles size={16} className="animate-pulse" />
            My Creative Work
          </div>
          <h2 className="text-5xl font-bold text-white mb-6">
            Projects Portfolio
          </h2>
          <p className="text-xl text-purple-200 max-w-3xl mx-auto leading-relaxed">
            A showcase of my programming projects ranging from community service applications 
            to interactive games and innovative utility tools.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div key={index} className={`group relative bg-gradient-to-r ${project.bgColor} backdrop-blur-sm rounded-2xl p-6 shadow-xl hover:shadow-2xl transition-all duration-500 hover:-translate-y-3 border border-white/20 ${project.featured ? 'lg:col-span-1 md:col-span-2' : ''}`}>
              {/* Featured badge */}
              {project.featured && (
                <div className="absolute -top-3 -right-3 bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1 animate-pulse">
                  <Star size={12} />
                  Featured
                </div>
              )}

              <div className={`w-16 h-16 bg-gradient-to-r ${project.color} rounded-2xl flex items-center justify-center mb-6 text-white group-hover:scale-110 group-hover:rotate-6 transition-all duration-300 shadow-lg`}>
                {project.icon}
              </div>
              
              <div className="mb-4">
                <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold bg-gradient-to-r ${project.color} text-white`}>
                  {project.category}
                </span>
              </div>
              
              <h3 className="text-2xl font-bold text-gray-900 mb-4 group-hover:text-purple-600 transition-colors">{project.title}</h3>
              <p className="text-gray-700 mb-6 leading-relaxed">{project.description}</p>
              
              <div className="flex flex-wrap gap-2 mb-6">
                {project.technologies.map((tech, techIndex) => (
                  <span key={techIndex} className="px-3 py-1 bg-white/80 text-gray-700 rounded-full text-sm font-medium border border-gray-200">
                    {tech}
                  </span>
                ))}
              </div>

              {/* Hover effect overlay */}
              <div className="absolute inset-0 bg-gradient-to-r from-purple-600/0 to-pink-600/0 group-hover:from-purple-600/10 group-hover:to-pink-600/10 rounded-2xl transition-all duration-300"></div>
            </div>
          ))}
        </div>

        <div className="text-center mt-16">
          <a 
            href="https://github.com/LeeladharNadupuri" 
            target="_blank" 
            rel="noopener noreferrer"
            className="group inline-flex items-center gap-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white px-8 py-4 rounded-2xl hover:from-purple-500 hover:to-pink-500 transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-xl font-semibold text-lg"
          >
            <Github size={24} className="group-hover:rotate-12 transition-transform" />
            Explore More on GitHub
            <ExternalLink size={20} className="group-hover:translate-x-1 transition-transform" />
          </a>
        </div>

        {/* Stats */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-8">
          {[
            { number: '7+', label: 'Projects Completed', icon: '🚀' },
            { number: '3+', label: 'Programming Languages', icon: '💻' },
            { number: '1', label: 'Community Project', icon: '🤝' },
            { number: '100%', label: 'Passion Driven', icon: '❤️' }
          ].map((stat, index) => (
            <div key={index} className="text-center group">
              <div className="text-4xl mb-2 group-hover:scale-110 transition-transform">{stat.icon}</div>
              <div className="text-3xl font-bold text-white mb-1">{stat.number}</div>
              <div className="text-purple-200 font-medium">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;