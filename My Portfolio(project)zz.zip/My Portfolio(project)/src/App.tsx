import React, { useState, useEffect, useRef } from 'react';
import emailjs from '@emailjs/browser';
import { 
  Menu, 
  X, 
  ChevronDown, 
  Mail, 
  Phone, 
  MapPin, 
  Github, 
  Linkedin, 
  ExternalLink,
  Code,
  Database,
  Smartphone,
  Globe,
  BookOpen,
  Award,
  Calendar,
  User,
  Briefcase,
  Heart,
  Shield,
  Calculator,
  Utensils,
  Gamepad2,
  Users,
  GraduationCap,
  Dumbbell,
  Send,
  CheckCircle,
  AlertCircle
} from 'lucide-react';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const [formStatus, setFormStatus] = useState<'idle' | 'sending' | 'success' | 'error'>('idle');
  const [formMessage, setFormMessage] = useState('');
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      const sections = ['home', 'about', 'education', 'projects', 'skills', 'contact'];
      const scrollPosition = window.scrollY + 100;

      sections.forEach(section => {
        const element = document.getElementById(section);
        if (element) {
          const offsetTop = element.offsetTop;
          const offsetHeight = element.offsetHeight;
          
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(section);
          }
        }
      });
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    if (!formRef.current) return;

    setFormStatus('sending');
    setFormMessage('');

    try {
      // Replace these with your actual EmailJS credentials
      const result = await emailjs.sendForm(
        'service_p37qxzk', // Replace with your EmailJS service ID
        'template_yydnc7a', // Replace with your EmailJS template ID
        formRef.current,
        'TJwilLHapgo52FFup' // Replace with your EmailJS public key
      );

      if (result.status === 200) {
        setFormStatus('success');
        setFormMessage('Thank you! Your message has been sent successfully. I\'ll get back to you soon.');
        formRef.current.reset();
      }
    } catch (error) {
      console.error('EmailJS Error:', error);
      setFormStatus('error');
      setFormMessage('Sorry, there was an error sending your message. Please try again or contact me directly via email.');
    }

    // Reset status after 5 seconds
    setTimeout(() => {
      setFormStatus('idle');
      setFormMessage('');
    }, 5000);
  };

  const skills = [
    { name: 'Python', level: 85, icon: Code },
    { name: 'HTML/CSS', level: 80, icon: Globe },
    { name: 'SQL', level: 75, icon: Database },
    { name: 'C Programming', level: 70, icon: Code },
    { name: 'C++', level: 70, icon: Code },
    { name: 'Database Management', level: 75, icon: Database },
    { name: 'Problem Solving', level: 85, icon: Code },
    { name: 'Software Development', level: 80, icon: Smartphone }
  ];

  const projects = [
    {
      title: 'Online UPI Transactions - Community Service',
      description: 'A comprehensive community service project focused on educating people about digital payment systems, UPI transactions, and promoting cashless economy in rural and urban areas.',
      technologies: ['Community Outreach', 'Digital Literacy', 'UPI Systems', 'Financial Education'],
      image: 'https://images.pexels.com/photos/4386321/pexels-photo-4386321.jpeg?auto=compress&cs=tinysrgb&w=800',
      demoLink: '#',
      codeLink: '#',
      category: 'Community Service',
      icon: Heart
    },
    {
      title: 'FitSpot - Fitness Website',
      description: 'A modern fitness website built with HTML and CSS featuring responsive design, workout plans, nutrition guides, and member registration. Clean interface with smooth animations and mobile-first approach.',
      technologies: ['HTML5', 'CSS3', 'Responsive Design', 'Flexbox'],
      image: 'https://images.pexels.com/photos/1552242/pexels-photo-1552242.jpeg?auto=compress&cs=tinysrgb&w=800',
      demoLink: '#',
      codeLink: '#',
      category: 'Web Development',
      icon: Dumbbell
    },
    {
      title: 'Student Result Management System',
      description: 'Python-based application for managing student grades, generating report cards, and tracking academic performance with data visualization and comprehensive reporting features.',
      technologies: ['Python', 'Tkinter', 'SQLite', 'Data Analysis'],
      image: 'https://images.pexels.com/photos/5212345/pexels-photo-5212345.jpeg?auto=compress&cs=tinysrgb&w=800',
      demoLink: '#',
      codeLink: '#',
      category: 'Python Project',
      icon: BookOpen
    },
    {
      title: 'Advanced Password Generator',
      description: 'Secure password generator with customizable length, character sets, and strength analysis. Includes password security tips and breach checking functionality.',
      technologies: ['Python', 'Tkinter', 'Security', 'Cryptography'],
      image: 'https://images.pexels.com/photos/60504/security-protection-anti-virus-software-60504.jpeg?auto=compress&cs=tinysrgb&w=800',
      demoLink: '#',
      codeLink: '#',
      category: 'Python Project',
      icon: Shield
    },
    {
      title: 'Rock Paper Scissors Game',
      description: 'Interactive game with computer AI, score tracking, game statistics, and multiple difficulty levels. Features engaging UI and intelligent computer opponent.',
      technologies: ['Python', 'Tkinter', 'Game Logic', 'AI'],
      image: 'https://images.pexels.com/photos/1040157/pexels-photo-1040157.jpeg?auto=compress&cs=tinysrgb&w=800',
      demoLink: '#',
      codeLink: '#',
      category: 'Python Project',
      icon: Gamepad2
    },
    {
      title: 'Love Calculator',
      description: 'Fun interactive application that calculates compatibility between two people using name analysis algorithms and provides entertaining relationship insights.',
      technologies: ['Python', 'Tkinter', 'Algorithm Design', 'GUI'],
      image: 'https://images.pexels.com/photos/1024993/pexels-photo-1024993.jpeg?auto=compress&cs=tinysrgb&w=800',
      demoLink: '#',
      codeLink: '#',
      category: 'Python Project',
      icon: Heart
    },
    {
      title: 'Restaurant Billing System',
      description: 'Complete restaurant management system with menu management, order processing, bill generation, tax calculations, and comprehensive sales reporting.',
      technologies: ['Python', 'Tkinter', 'SQLite', 'Business Logic'],
      image: 'https://images.pexels.com/photos/262978/pexels-photo-262978.jpeg?auto=compress&cs=tinysrgb&w=800',
      demoLink: '#',
      codeLink: '#',
      category: 'Python Project',
      icon: Utensils
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-white/10 backdrop-blur-lg border-b border-white/20 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="text-2xl font-bold text-white">
              Portfolio
            </div>
            
            {/* Desktop Menu */}
            <div className="hidden md:flex space-x-8">
              {['home', 'about', 'education', 'projects', 'skills', 'contact'].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item)}
                  className={`capitalize transition-all duration-300 ${
                    activeSection === item 
                      ? 'text-blue-400 font-semibold' 
                      : 'text-white/80 hover:text-white'
                  }`}
                >
                  {item}
                </button>
              ))}
            </div>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden text-white"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          {/* Mobile Menu */}
          {isMenuOpen && (
            <div className="md:hidden py-4 space-y-2">
              {['home', 'about', 'education', 'projects', 'skills', 'contact'].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item)}
                  className="block w-full text-left px-4 py-2 text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition-all duration-300 capitalize"
                >
                  {item}
                </button>
              ))}
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="min-h-screen flex items-center justify-center px-4 pt-20">
        <div className="max-w-4xl mx-auto text-center">
          <div className="animate-fade-in-up">
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6">
              Hi, I'm <span className="bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">Nadupuri Leeladhar</span>
            </h1>
            <p className="text-xl md:text-2xl text-white/80 mb-8 max-w-2xl mx-auto">
              Final Year BCA Student & Aspiring Software Developer passionate about creating innovative digital solutions
            </p>
            <div className="flex justify-center">
              <button
                onClick={() => scrollToSection('projects')}
                className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-8 py-4 rounded-full font-semibold hover:scale-105 transition-all duration-300 shadow-lg"
              >
                View My Work
              </button>
            </div>
          </div>
          
          {/* Scroll Indicator */}
          <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
            <ChevronDown className="text-white/60" size={32} />
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-4 bg-white/5 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-white text-center mb-16">About Me</h2>
          
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="relative group">
                {/* Profile Picture Container */}
                <div className="w-80 h-80 mx-auto md:mx-0 rounded-2xl bg-gradient-to-br from-blue-400 via-purple-500 to-pink-500 p-1 shadow-2xl">
                  <div className="w-full h-full rounded-2xl overflow-hidden bg-gray-100 relative">
                    {/* Professional placeholder - To use your photo, upload it to an image hosting service like Imgur, Cloudinary, or GitHub */}
                    <img 
                      src="https://i.imgur.com/CRmMKL5.jpeg" 
                      alt="Nadupuri Leeladhar - BCA Student"
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                    {/* Overlay gradient for better visual appeal */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  </div>
                </div>
                
                {/* Floating elements for visual interest */}
                <div className="absolute -top-4 -right-4 w-8 h-8 bg-blue-400 rounded-full animate-pulse"></div>
                <div className="absolute -bottom-4 -left-4 w-6 h-6 bg-purple-400 rounded-full animate-pulse delay-1000"></div>
              </div>
            </div>
            
            <div className="space-y-6">
              <h3 className="text-2xl font-semibold text-white">Final Year BCA Student & Future Developer</h3>
              <p className="text-white/80 text-lg leading-relaxed">
                I'm Nadupuri Leeladhar, a dedicated final year BCA student at Aditya Degree College Gopalapatnam 
                with a passion for technology and software development. My journey in computer applications has 
                equipped me with strong programming skills and a deep understanding of software development principles.
              </p>
              <p className="text-white/80 text-lg leading-relaxed">
                I have hands-on experience in Python programming, database management, and web technologies. 
                Through various projects including community service initiatives and technical applications, 
                I've developed strong problem-solving abilities and a commitment to creating meaningful digital solutions.
              </p>
              
              <div className="grid grid-cols-2 gap-4 mt-8">
                <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 hover:bg-white/15 transition-all duration-300">
                  <BookOpen className="text-blue-400 mb-2" size={24} />
                  <h4 className="text-white font-semibold">Education</h4>
                  <p className="text-white/70 text-sm">BCA Final Year</p>
                </div>
                <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 hover:bg-white/15 transition-all duration-300">
                  <Code className="text-purple-400 mb-2" size={24} />
                  <h4 className="text-white font-semibold">Focus</h4>
                  <p className="text-white/70 text-sm">Software Development</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Education Section */}
      <section id="education" className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-white text-center mb-16">Education & Achievements</h2>
          
          <div className="space-y-8">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 border border-white/20 hover:bg-white/15 transition-all duration-300">
              <div className="flex items-start gap-4">
                <div className="bg-blue-500 rounded-full p-3">
                  <BookOpen className="text-white" size={24} />
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold text-white mb-2">Bachelor of Computer Applications (BCA)</h3>
                  <p className="text-blue-400 font-medium mb-2">Aditya Degree College Gopalapatnam</p>
                  <div className="flex items-center gap-4 text-white/70 mb-4">
                    <div className="flex items-center gap-1">
                      <Calendar size={16} />
                      <span>2023 - 2026</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Award size={16} />
                      <span>Final Year Student</span>
                    </div>
                  </div>
                  <p className="text-white/80">
                    Comprehensive study of computer applications, software development, database management, 
                    programming languages, and system analysis. Actively working on various projects and 
                    developing practical skills in software development.
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 border border-white/20 hover:bg-white/15 transition-all duration-300">
              <div className="flex items-start gap-4">
                <div className="bg-purple-500 rounded-full p-3">
                  <Award className="text-white" size={24} />
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold text-white mb-2">Intermediate Education</h3>
                  <p className="text-purple-400 font-medium mb-2">NRI Junior College</p>
                  <div className="flex items-center gap-4 text-white/70 mb-4">
                    <div className="flex items-center gap-1">
                      <Calendar size={16} />
                      <span>2021 - 2023</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Award size={16} />
                      <span>79.1%</span>
                    </div>
                  </div>
                  <p className="text-white/80">
                    Completed intermediate education with strong performance in Mathematics and Science subjects. 
                    Built foundation in analytical thinking and problem-solving skills that led to pursuing 
                    computer applications.
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 border border-white/20 hover:bg-white/15 transition-all duration-300">
              <div className="flex items-start gap-4">
                <div className="bg-green-500 rounded-full p-3">
                  <GraduationCap className="text-white" size={24} />
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-semibold text-white mb-2">Secondary School Education</h3>
                  <p className="text-green-400 font-medium mb-2">Govt High School Sabbavaram</p>
                  <div className="flex items-center gap-4 text-white/70 mb-4">
                    <div className="flex items-center gap-1">
                      <Calendar size={16} />
                      <span>Completed</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Award size={16} />
                      <span>CGPA: 8.8/10</span>
                    </div>
                  </div>
                  <p className="text-white/80">
                    Completed secondary education with excellent academic performance. Achieved strong CGPA of 8.8, 
                    demonstrating consistent academic excellence and laying the foundation for higher studies in 
                    computer applications.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 px-4 bg-white/5 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-white text-center mb-8">Featured Projects</h2>
          <p className="text-white/70 text-center mb-16 max-w-2xl mx-auto">
            A showcase of my technical skills through community service initiatives, web development, and Python programming projects
          </p>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => {
              const IconComponent = project.icon;
              return (
                <div key={index} className="group bg-white/10 backdrop-blur-sm rounded-xl overflow-hidden border border-white/20 hover:transform hover:scale-105 transition-all duration-300">
                  <div className="aspect-video overflow-hidden relative">
                    <img 
                      src={project.image} 
                      alt={project.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                    {/* Category Badge */}
                    <div className="absolute top-4 left-4 flex items-center gap-2 bg-black/50 backdrop-blur-sm rounded-full px-3 py-1">
                      <IconComponent size={16} className="text-white" />
                      <span className="text-white text-xs font-medium">{project.category}</span>
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-semibold text-white mb-3">{project.title}</h3>
                    <p className="text-white/80 mb-4 leading-relaxed text-sm">{project.description}</p>
                    
                    <div className="flex flex-wrap gap-2 mb-4">
                      {project.technologies.map((tech, techIndex) => (
                        <span key={techIndex} className="bg-blue-500/20 text-blue-300 px-3 py-1 rounded-full text-xs">
                          {tech}
                        </span>
                      ))}
                    </div>
                    
                    <div className="flex gap-4">
                      <a href={project.demoLink} className="flex items-center gap-2 text-blue-400 hover:text-blue-300 transition-colors text-sm">
                        <ExternalLink size={14} />
                        Demo
                      </a>
                      <a href={project.codeLink} className="flex items-center gap-2 text-purple-400 hover:text-purple-300 transition-colors text-sm">
                        <Github size={14} />
                        Code
                      </a>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Project Categories Summary */}
          <div className="mt-16 grid md:grid-cols-3 gap-6">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20 text-center">
              <Heart className="text-red-400 mx-auto mb-4" size={32} />
              <h4 className="text-white font-semibold mb-2">Community Service</h4>
              <p className="text-white/70 text-sm">Digital literacy and UPI transaction education</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20 text-center">
              <Code className="text-blue-400 mx-auto mb-4" size={32} />
              <h4 className="text-white font-semibold mb-2">Python Projects</h4>
              <p className="text-white/70 text-sm">Desktop applications and utility tools</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20 text-center">
              <Globe className="text-green-400 mx-auto mb-4" size={32} />
              <h4 className="text-white font-semibold mb-2">Web Development</h4>
              <p className="text-white/70 text-sm">Modern responsive websites and applications</p>
            </div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-white text-center mb-16">Technical Skills</h2>
          
          <div className="grid md:grid-cols-2 gap-8">
            {skills.map((skill, index) => {
              const IconComponent = skill.icon;
              return (
                <div key={index} className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20 hover:bg-white/15 transition-all duration-300">
                  <div className="flex items-center gap-4 mb-4">
                    <IconComponent className="text-blue-400" size={24} />
                    <h3 className="text-white font-semibold text-lg">{skill.name}</h3>
                    <span className="text-white/70 ml-auto">{skill.level}%</span>
                  </div>
                  <div className="bg-white/20 rounded-full h-3">
                    <div 
                      className="bg-gradient-to-r from-blue-500 to-purple-500 h-3 rounded-full transition-all duration-1000 ease-out"
                      style={{ width: `${skill.level}%` }}
                    ></div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-4 bg-white/5 backdrop-blur-sm">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold text-white text-center mb-16">Get In Touch</h2>
          
          <div className="grid md:grid-cols-2 gap-12">
            <div className="space-y-8">
              <div>
                <h3 className="text-2xl font-semibold text-white mb-6">Let's Connect!</h3>
                <p className="text-white/80 text-lg mb-8">
                  I'm actively looking for opportunities to start my career in software development. 
                  Let's discuss how I can contribute to your team with my technical skills and fresh perspective!
                </p>
              </div>
              
              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <Mail className="text-blue-400" size={24} />
                  <div>
                    <p className="text-white font-medium">Email</p>
                    <a href="mailto:nleela006@gmail.com" className="text-white/80 hover:text-blue-400 transition-colors">
                      nleela006@gmail.com
                    </a>
                  </div>
                </div>
                
                <div className="flex items-center gap-4">
                  <Phone className="text-purple-400" size={24} />
                  <div>
                    <p className="text-white font-medium">Phone</p>
                    <a href="tel:+918179885181" className="text-white/80 hover:text-purple-400 transition-colors">
                      +91 8179885181
                    </a>
                  </div>
                </div>
                
                <div className="flex items-center gap-4">
                  <MapPin className="text-green-400" size={24} />
                  <div>
                    <p className="text-white font-medium">Location</p>
                    <p className="text-white/80">Visakhapatnam, India</p>
                  </div>
                </div>
              </div>
              
              <div className="flex gap-4 pt-4">
                <a 
                  href="https://www.linkedin.com/in/leeladhar-nadupuri-233b1b331?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="bg-blue-600 hover:bg-blue-700 p-3 rounded-full transition-colors group"
                  title="Connect on LinkedIn"
                >
                  <Linkedin className="text-white group-hover:scale-110 transition-transform" size={24} />
                </a>
                <a 
                  href="https://github.com/LeeladharNadupuri" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="bg-gray-800 hover:bg-gray-700 p-3 rounded-full transition-colors group"
                  title="View GitHub Profile"
                >
                  <Github className="text-white group-hover:scale-110 transition-transform" size={24} />
                </a>
              </div>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-8 border border-white/20">
              <form ref={formRef} onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <input
                    type="text"
                    name="from_name"
                    placeholder="Your Name"
                    required
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <input
                    type="email"
                    name="from_email"
                    placeholder="Your Email"
                    required
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <input
                    type="text"
                    name="subject"
                    placeholder="Subject"
                    required
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <textarea
                    name="message"
                    rows={5}
                    placeholder="Your Message"
                    required
                    className="w-full bg-white/10 border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
                  ></textarea>
                </div>
                
                {/* Status Message */}
                {formMessage && (
                  <div className={`flex items-center gap-2 p-4 rounded-lg ${
                    formStatus === 'success' 
                      ? 'bg-green-500/20 border border-green-500/30 text-green-300' 
                      : 'bg-red-500/20 border border-red-500/30 text-red-300'
                  }`}>
                    {formStatus === 'success' ? (
                      <CheckCircle size={20} />
                    ) : (
                      <AlertCircle size={20} />
                    )}
                    <p className="text-sm">{formMessage}</p>
                  </div>
                )}
                
                <button
                  type="submit"
                  disabled={formStatus === 'sending'}
                  className={`w-full py-3 rounded-lg font-semibold transition-all duration-300 flex items-center justify-center gap-2 ${
                    formStatus === 'sending'
                      ? 'bg-gray-600 cursor-not-allowed'
                      : 'bg-gradient-to-r from-blue-500 to-purple-600 hover:scale-105'
                  } text-white`}
                >
                  {formStatus === 'sending' ? (
                    <>
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                      Sending...
                    </>
                  ) : (
                    <>
                      <Send size={20} />
                      Send Message
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 border-t border-white/20">
        <div className="max-w-6xl mx-auto text-center">
          <p className="text-white/60">
            © 2024 Nadupuri Leeladhar. Designed & Built with React and Tailwind CSS.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;