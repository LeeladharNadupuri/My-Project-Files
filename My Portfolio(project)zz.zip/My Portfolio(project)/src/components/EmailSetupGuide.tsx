import React from 'react';
import { Mail, Settings, Key, Globe, Copy, CheckCircle } from 'lucide-react';

const EmailSetupGuide = () => {
  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <div className="max-w-6xl mx-auto p-6 bg-white/10 backdrop-blur-sm rounded-xl border border-white/20">
      <h2 className="text-3xl font-bold text-white mb-8 flex items-center gap-3">
        <Mail className="text-blue-400" />
        Complete EmailJS Setup Guide
      </h2>
      
      <div className="space-y-8 text-white/80">
        <div className="bg-blue-500/20 border border-blue-500/30 rounded-lg p-6">
          <p className="text-blue-300 font-medium mb-2 text-lg">📧 Goal: Receive contact form messages in your Gmail</p>
          <p>Follow these exact steps to connect your portfolio contact form to your Gmail account.</p>
        </div>

        {/* Step 1 */}
        <div className="bg-white/5 rounded-xl p-6 border border-white/10">
          <div className="flex items-start gap-4">
            <div className="bg-blue-500 rounded-full p-3 mt-1 flex-shrink-0">
              <span className="text-white font-bold">1</span>
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-semibold text-white mb-4">Create EmailJS Account</h3>
              <div className="space-y-3">
                <p>• Go to <a href="https://www.emailjs.com/" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:underline font-medium">https://www.emailjs.com/</a></p>
                <p>• Click "Sign Up" (top right corner)</p>
                <p>• Use your Gmail address to sign up</p>
                <p>• Verify your email when you receive the confirmation</p>
                <p>• Log in to your EmailJS dashboard</p>
              </div>
            </div>
          </div>
        </div>

        {/* Step 2 */}
        <div className="bg-white/5 rounded-xl p-6 border border-white/10">
          <div className="flex items-start gap-4">
            <div className="bg-purple-500 rounded-full p-3 mt-1 flex-shrink-0">
              <span className="text-white font-bold">2</span>
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-semibold text-white mb-4">Add Gmail Service</h3>
              <div className="space-y-3">
                <p>• In your EmailJS dashboard, click <strong>"Email Services"</strong> in the left menu</p>
                <p>• Click the <strong>"Add New Service"</strong> button</p>
                <p>• Select <strong>"Gmail"</strong> from the list of providers</p>
                <p>• Click <strong>"Connect Account"</strong> and sign in with your Gmail</p>
                <p>• Give your service a name (e.g., "Portfolio Contact Form")</p>
                <p>• Click <strong>"Create Service"</strong></p>
                <p>• <strong>IMPORTANT:</strong> Copy the <strong>Service ID</strong> (it looks like: service_xxxxxxx)</p>
              </div>
              <div className="bg-yellow-500/20 border border-yellow-500/30 rounded-lg p-4 mt-4">
                <p className="text-yellow-300 font-medium">💡 Save your Service ID - you'll need it later!</p>
              </div>
            </div>
          </div>
        </div>

        {/* Step 3 - Most Important */}
        <div className="bg-white/5 rounded-xl p-6 border border-white/10">
          <div className="flex items-start gap-4">
            <div className="bg-green-500 rounded-full p-3 mt-1 flex-shrink-0">
              <span className="text-white font-bold">3</span>
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-semibold text-white mb-4">Create Email Template (MOST IMPORTANT STEP)</h3>
              
              <div className="space-y-4">
                <div>
                  <p className="mb-3">• Click <strong>"Email Templates"</strong> in the left menu</p>
                  <p className="mb-3">• Click <strong>"Create New Template"</strong></p>
                  <p className="mb-4">• You'll see a template editor with two sections:</p>
                </div>

                <div className="bg-gray-800 rounded-lg p-4 space-y-4">
                  <div>
                    <h4 className="text-white font-semibold mb-2">📧 Email Subject Line:</h4>
                    <div className="bg-gray-900 rounded p-3 font-mono text-sm text-green-300 relative">
                      <span>New Contact Form Message from Portfolio - {'{{subject}}'}</span>
                      <button 
                        onClick={() => copyToClipboard('New Contact Form Message from Portfolio - {{subject}}')}
                        className="absolute right-2 top-2 text-gray-400 hover:text-white"
                      >
                        <Copy size={16} />
                      </button>
                    </div>
                  </div>

                  <div>
                    <h4 className="text-white font-semibold mb-2">📝 Email Body Content:</h4>
                    <div className="bg-gray-900 rounded p-4 font-mono text-sm text-green-300 relative">
                      <div className="whitespace-pre-line">
{`You have received a new message from your portfolio contact form:

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

👤 FROM: {{from_name}}
📧 EMAIL: {{from_email}}
📋 SUBJECT: {{subject}}

💬 MESSAGE:
{{message}}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

This message was sent from your portfolio website contact form.
Reply directly to this email to respond to {{from_name}}.`}
                      </div>
                      <button 
                        onClick={() => copyToClipboard(`You have received a new message from your portfolio contact form:

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

👤 FROM: {{from_name}}
📧 EMAIL: {{from_email}}
📋 SUBJECT: {{subject}}

💬 MESSAGE:
{{message}}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

This message was sent from your portfolio website contact form.
Reply directly to this email to respond to {{from_name}}.`)}
                        className="absolute right-2 top-2 text-gray-400 hover:text-white"
                      >
                        <Copy size={16} />
                      </button>
                    </div>
                  </div>
                </div>

                <div className="bg-red-500/20 border border-red-500/30 rounded-lg p-4">
                  <h4 className="text-red-300 font-semibold mb-2">🚨 CRITICAL: Template Variables</h4>
                  <p className="text-sm mb-2">These variables MUST match exactly (including the double curly braces):</p>
                  <div className="grid grid-cols-2 gap-2 text-sm font-mono">
                    <div>• <span className="text-yellow-300">{'{{from_name}}'}</span> - Sender's name</div>
                    <div>• <span className="text-yellow-300">{'{{from_email}}'}</span> - Sender's email</div>
                    <div>• <span className="text-yellow-300">{'{{subject}}'}</span> - Message subject</div>
                    <div>• <span className="text-yellow-300">{'{{message}}'}</span> - Message content</div>
                  </div>
                </div>

                <div>
                  <p>• After pasting the template content, click <strong>"Save"</strong></p>
                  <p>• <strong>IMPORTANT:</strong> Copy the <strong>Template ID</strong> (it looks like: template_xxxxxxx)</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Step 4 */}
        <div className="bg-white/5 rounded-xl p-6 border border-white/10">
          <div className="flex items-start gap-4">
            <div className="bg-orange-500 rounded-full p-3 mt-1 flex-shrink-0">
              <span className="text-white font-bold">4</span>
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-semibold text-white mb-4">Get Your Public Key</h3>
              <div className="space-y-3">
                <p>• Click <strong>"Account"</strong> in the left menu</p>
                <p>• Click <strong>"General"</strong> tab</p>
                <p>• Find the <strong>"Public Key"</strong> section</p>
                <p>• <strong>IMPORTANT:</strong> Copy your <strong>Public Key</strong> (it looks like: user_xxxxxxxxxxxxxxxxx)</p>
              </div>
            </div>
          </div>
        </div>

        {/* Step 5 */}
        <div className="bg-white/5 rounded-xl p-6 border border-white/10">
          <div className="flex items-start gap-4">
            <div className="bg-red-500 rounded-full p-3 mt-1 flex-shrink-0">
              <span className="text-white font-bold">5</span>
            </div>
            <div className="flex-1">
              <h3 className="text-xl font-semibold text-white mb-4">Update Your Portfolio Code</h3>
              <div className="space-y-4">
                <p>Find these lines in your App.tsx file (around line 52-56):</p>
                
                <div className="bg-gray-800 rounded-lg p-4">
                  <h4 className="text-white font-semibold mb-2">🔍 Find this code:</h4>
                  <div className="bg-gray-900 rounded p-3 font-mono text-sm text-red-300">
{`const result = await emailjs.sendForm(
  'YOUR_SERVICE_ID', // Replace with your EmailJS service ID
  'YOUR_TEMPLATE_ID', // Replace with your EmailJS template ID
  formRef.current,
  'YOUR_PUBLIC_KEY' // Replace with your EmailJS public key
);`}
                  </div>
                </div>

                <div className="bg-gray-800 rounded-lg p-4">
                  <h4 className="text-white font-semibold mb-2">✅ Replace with your actual values:</h4>
                  <div className="bg-gray-900 rounded p-3 font-mono text-sm text-green-300">
{`const result = await emailjs.sendForm(
  'service_xxxxxxx', // Your Service ID from Step 2
  'template_xxxxxxx', // Your Template ID from Step 3
  formRef.current,
  'user_xxxxxxxxxxxxxxxxx' // Your Public Key from Step 4
);`}
                  </div>
                </div>

                <div className="bg-yellow-500/20 border border-yellow-500/30 rounded-lg p-4">
                  <p className="text-yellow-300 font-medium">⚠️ Keep the single quotes around your IDs!</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Final Result */}
        <div className="bg-green-500/20 border border-green-500/30 rounded-lg p-6">
          <div className="flex items-start gap-4">
            <CheckCircle className="text-green-400 mt-1" size={24} />
            <div>
              <h3 className="text-green-300 font-semibold text-lg mb-2">🎉 You're Done!</h3>
              <div className="space-y-2 text-sm">
                <p>✅ When someone fills out your contact form and clicks "Send Message"</p>
                <p>✅ You'll receive a formatted email in your Gmail inbox</p>
                <p>✅ The email will contain all the form details</p>
                <p>✅ You can reply directly to respond to the person</p>
                <p>✅ Your contact form will show success/error messages</p>
              </div>
            </div>
          </div>
        </div>

        {/* Troubleshooting */}
        <div className="bg-gray-800 rounded-xl p-6 border border-gray-600">
          <h3 className="text-white font-semibold text-lg mb-4">🔧 Troubleshooting</h3>
          <div className="space-y-3 text-sm">
            <div>
              <p className="text-red-300 font-medium">❌ If emails aren't sending:</p>
              <ul className="ml-4 space-y-1 text-gray-300">
                <li>• Double-check your Service ID, Template ID, and Public Key</li>
                <li>• Make sure template variables match exactly: {'{{from_name}}'}, {'{{from_email}}'}, etc.</li>
                <li>• Check browser console for error messages</li>
                <li>• Verify your Gmail service is connected in EmailJS</li>
              </ul>
            </div>
            <div>
              <p className="text-yellow-300 font-medium">⚠️ Free plan limits:</p>
              <ul className="ml-4 space-y-1 text-gray-300">
                <li>• 200 emails per month on free plan</li>
                <li>• Upgrade if you need more</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmailSetupGuide;